﻿using System;
using System.Collections.Generic;

namespace NewsArticles.Models
{
    public class Article
    {
        public int ArticleId { get; set; }
        public string ArticleTitle { get; set; }
        public string Description { get; set; }
        public int ReadTime { get; set; }
        public string ImageURL { get; set; }

        public static Article GetArticle()
        {
            Article article = new Article() { ArticleId = 1, ArticleTitle = "", Description = "", ReadTime = 1, ImageURL = "" };
            return article;
        }

        public static List<Article> GetAllArticles()
        {
            List<Article> articles = new List<Article>() {
                new Article() { ArticleId = 1, ArticleTitle = "Why demand for in-store contactless payments is here to stay", Description = "The demand for in-store contactless payment technology has increased over the past two years.learn more about this growing trend and how you can leverage it.", ReadTime = 4 , ImageURL = "https://images.unsplash.com/photo-1556741533-974f8e62a92d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80"},
                new Article() { ArticleId = 2, ArticleTitle = "7 ways to increase ecommerce sales", Description = "Increase ecommerce sales white these ideas to improve your customers online payment experience.", ReadTime = 6 , ImageURL = "https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2340&q=80"},
                new Article() { ArticleId = 3, ArticleTitle = "How technology empowers businesses to prepare for the future of commerce", Description = "The future of commerce is ever changing. Learn how our future-forward commerce technology keeps businesses at the forefront and removes complexity.", ReadTime =5 , ImageURL = "https://images.unsplash.com/photo-1488590528505-98d2b5aba04b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2070&q=80"}
            };

            return articles;
        }
    }
}
