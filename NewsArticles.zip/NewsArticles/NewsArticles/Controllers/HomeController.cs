﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NewsArticles.Models;

namespace NewsArticles.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            List<Article> articles = Article.GetAllArticles();
            return View(articles);
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
